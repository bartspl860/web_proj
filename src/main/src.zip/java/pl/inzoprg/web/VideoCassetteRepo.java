package pl.inzoprg.web;

import org.springframework.data.repository.CrudRepository;

public interface VideoCassetteRepo extends CrudRepository<VideoCassete, Long> {

}

